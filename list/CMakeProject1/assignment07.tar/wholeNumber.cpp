/****************************************
 * Header file 
 *    Whole Number class cpp file
 * 
 * Author:
 *      Isabel Ding and Branden Hansen
 * 
 ****************************************/