/****************************************
 * Header file 
 *    Whole Number class
 * 
 * Author:
 *      Isabel Ding and Branden Hansen
 * 
 ****************************************/
#ifndef WHOLENUMBER_H
#define WHOLENUMBER_H

using namespace std;

/************************************************
* wholenumber class
***********************************************/
template <class T>



#endif